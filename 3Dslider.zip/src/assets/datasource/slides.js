let slides;
export default slides = [
    {
        title: "Assesment Test Pilot",
        image: "https://swiperjs.com/demos/images/nature-1.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/5df1e219-9697-450b-8547-742307da00bd/uslife_inc.ppt"
    },
    {
        title: "Pwc Professional",
        image: "https://swiperjs.com/demos/images/nature-2.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/2f6d753d-fafd-4fea-991d-241b4e3da026/hlth_inceg.ppt"
    },
    {
        title: "Skill Management",
        image: "https://swiperjs.com/demos/images/nature-3.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/318f961d-af89-48a9-845a-85bc35bfc140/ed_lifexp.ppt"
    },
    {
        title: "My Profile",
        image: "https://swiperjs.com/demos/images/nature-4.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/4187fe40-f70b-4a5f-abeb-d170d87b32a6/US%20Life%20Expectancy%20Map.ppt"
    },
    {
        title: "Dashboard",
        image: "https://swiperjs.com/demos/images/nature-5.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/421cd357-255c-4b8e-96f3-835fd391962e/ed_chelth.ppt"
    },
    {
        title: "Assesment Test Pilot",
        image: "https://swiperjs.com/demos/images/nature-1.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/5df1e219-9697-450b-8547-742307da00bd/uslife_inc.ppt"
    },
    {
        title: "Pwc Professional",
        image: "https://swiperjs.com/demos/images/nature-2.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/2f6d753d-fafd-4fea-991d-241b4e3da026/hlth_inceg.ppt"
    },
    {
        title: "Skill Management",
        image: "https://swiperjs.com/demos/images/nature-3.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/318f961d-af89-48a9-845a-85bc35bfc140/ed_lifexp.ppt"
    },
    {
        title: "My Profile",
        image: "https://swiperjs.com/demos/images/nature-4.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/4187fe40-f70b-4a5f-abeb-d170d87b32a6/US%20Life%20Expectancy%20Map.ppt"
    },
    {
        title: "Dashboard",
        image: "https://swiperjs.com/demos/images/nature-5.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/421cd357-255c-4b8e-96f3-835fd391962e/ed_chelth.ppt"
    },
    {
        title: "Assesment Test Pilot",
        image: "https://swiperjs.com/demos/images/nature-1.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/5df1e219-9697-450b-8547-742307da00bd/uslife_inc.ppt"
    },
    {
        title: "Pwc Professional",
        image: "https://swiperjs.com/demos/images/nature-2.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/2f6d753d-fafd-4fea-991d-241b4e3da026/hlth_inceg.ppt"
    },
    {
        title: "Skill Management",
        image: "https://swiperjs.com/demos/images/nature-3.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/318f961d-af89-48a9-845a-85bc35bfc140/ed_lifexp.ppt"
    },
    {
        title: "My Profile",
        image: "https://swiperjs.com/demos/images/nature-4.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/4187fe40-f70b-4a5f-abeb-d170d87b32a6/US%20Life%20Expectancy%20Map.ppt"
    },
    {
        title: "Dashboard",
        image: "https://swiperjs.com/demos/images/nature-5.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/421cd357-255c-4b8e-96f3-835fd391962e/ed_chelth.ppt"
    },
    {
        title: "Assesment Test Pilot",
        image: "https://swiperjs.com/demos/images/nature-1.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/5df1e219-9697-450b-8547-742307da00bd/uslife_inc.ppt"
    },
    {
        title: "Pwc Professional",
        image: "https://swiperjs.com/demos/images/nature-2.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/2f6d753d-fafd-4fea-991d-241b4e3da026/hlth_inceg.ppt"
    },
    {
        title: "Skill Management",
        image: "https://swiperjs.com/demos/images/nature-3.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/318f961d-af89-48a9-845a-85bc35bfc140/ed_lifexp.ppt"
    },
    {
        title: "My Profile",
        image: "https://swiperjs.com/demos/images/nature-4.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/4187fe40-f70b-4a5f-abeb-d170d87b32a6/US%20Life%20Expectancy%20Map.ppt"
    },
    {
        title: "Dashboard",
        image: "https://swiperjs.com/demos/images/nature-5.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/421cd357-255c-4b8e-96f3-835fd391962e/ed_chelth.ppt"
    },
    {
        title: "Assesment Test Pilot",
        image: "https://swiperjs.com/demos/images/nature-1.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/5df1e219-9697-450b-8547-742307da00bd/uslife_inc.ppt"
    },
    {
        title: "Pwc Professional",
        image: "https://swiperjs.com/demos/images/nature-2.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/2f6d753d-fafd-4fea-991d-241b4e3da026/hlth_inceg.ppt"
    },
    {
        title: "Skill Management",
        image: "https://swiperjs.com/demos/images/nature-3.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/318f961d-af89-48a9-845a-85bc35bfc140/ed_lifexp.ppt"
    },
    {
        title: "My Profile",
        image: "https://swiperjs.com/demos/images/nature-4.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/4187fe40-f70b-4a5f-abeb-d170d87b32a6/US%20Life%20Expectancy%20Map.ppt"
    },
    {
        title: "Dashboard",
        image: "https://swiperjs.com/demos/images/nature-5.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/421cd357-255c-4b8e-96f3-835fd391962e/ed_chelth.ppt"
    },
    {
        title: "Assesment Test Pilot",
        image: "https://swiperjs.com/demos/images/nature-1.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/5df1e219-9697-450b-8547-742307da00bd/uslife_inc.ppt"
    },
    {
        title: "Pwc Professional",
        image: "https://swiperjs.com/demos/images/nature-2.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/2f6d753d-fafd-4fea-991d-241b4e3da026/hlth_inceg.ppt"
    },
    {
        title: "Skill Management",
        image: "https://swiperjs.com/demos/images/nature-3.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/318f961d-af89-48a9-845a-85bc35bfc140/ed_lifexp.ppt"
    },
    {
        title: "My Profile",
        image: "https://swiperjs.com/demos/images/nature-4.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/4187fe40-f70b-4a5f-abeb-d170d87b32a6/US%20Life%20Expectancy%20Map.ppt"
    },
    {
        title: "Dashboard",
        image: "https://swiperjs.com/demos/images/nature-5.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/421cd357-255c-4b8e-96f3-835fd391962e/ed_chelth.ppt"
    },
    {
        title: "Assesment Test Pilot",
        image: "https://swiperjs.com/demos/images/nature-1.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/5df1e219-9697-450b-8547-742307da00bd/uslife_inc.ppt"
    },
    {
        title: "Pwc Professional",
        image: "https://swiperjs.com/demos/images/nature-2.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/2f6d753d-fafd-4fea-991d-241b4e3da026/hlth_inceg.ppt"
    },
    {
        title: "Skill Management",
        image: "https://swiperjs.com/demos/images/nature-3.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/318f961d-af89-48a9-845a-85bc35bfc140/ed_lifexp.ppt"
    },
    {
        title: "My Profile",
        image: "https://swiperjs.com/demos/images/nature-4.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/4187fe40-f70b-4a5f-abeb-d170d87b32a6/US%20Life%20Expectancy%20Map.ppt"
    },
    {
        title: "Dashboard",
        image: "https://swiperjs.com/demos/images/nature-5.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/421cd357-255c-4b8e-96f3-835fd391962e/ed_chelth.ppt"
    },
    {
        title: "Assesment Test Pilot",
        image: "https://swiperjs.com/demos/images/nature-1.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/5df1e219-9697-450b-8547-742307da00bd/uslife_inc.ppt"
    },
    {
        title: "Pwc Professional",
        image: "https://swiperjs.com/demos/images/nature-2.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/2f6d753d-fafd-4fea-991d-241b4e3da026/hlth_inceg.ppt"
    },
    {
        title: "Skill Management",
        image: "https://swiperjs.com/demos/images/nature-3.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/318f961d-af89-48a9-845a-85bc35bfc140/ed_lifexp.ppt"
    },
    {
        title: "My Profile",
        image: "https://swiperjs.com/demos/images/nature-4.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/4187fe40-f70b-4a5f-abeb-d170d87b32a6/US%20Life%20Expectancy%20Map.ppt"
    },
    {
        title: "Dashboard",
        image: "https://swiperjs.com/demos/images/nature-5.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/421cd357-255c-4b8e-96f3-835fd391962e/ed_chelth.ppt"
    },
    {
        title: "Assesment Test Pilot",
        image: "https://swiperjs.com/demos/images/nature-1.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/5df1e219-9697-450b-8547-742307da00bd/uslife_inc.ppt"
    },
    {
        title: "Pwc Professional",
        image: "https://swiperjs.com/demos/images/nature-2.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/2f6d753d-fafd-4fea-991d-241b4e3da026/hlth_inceg.ppt"
    },
    {
        title: "Skill Management",
        image: "https://swiperjs.com/demos/images/nature-3.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/318f961d-af89-48a9-845a-85bc35bfc140/ed_lifexp.ppt"
    },
    {
        title: "My Profile",
        image: "https://swiperjs.com/demos/images/nature-4.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/4187fe40-f70b-4a5f-abeb-d170d87b32a6/US%20Life%20Expectancy%20Map.ppt"
    },
    {
        title: "Dashboard",
        image: "https://swiperjs.com/demos/images/nature-5.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/421cd357-255c-4b8e-96f3-835fd391962e/ed_chelth.ppt"
    },
    {
        title: "Assesment Test Pilot",
        image: "https://swiperjs.com/demos/images/nature-1.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/5df1e219-9697-450b-8547-742307da00bd/uslife_inc.ppt"
    },
    {
        title: "Pwc Professional",
        image: "https://swiperjs.com/demos/images/nature-2.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/2f6d753d-fafd-4fea-991d-241b4e3da026/hlth_inceg.ppt"
    },
    {
        title: "Skill Management",
        image: "https://swiperjs.com/demos/images/nature-3.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/318f961d-af89-48a9-845a-85bc35bfc140/ed_lifexp.ppt"
    },
    {
        title: "My Profile",
        image: "https://swiperjs.com/demos/images/nature-4.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/4187fe40-f70b-4a5f-abeb-d170d87b32a6/US%20Life%20Expectancy%20Map.ppt"
    },
    {
        title: "Dashboard",
        image: "https://swiperjs.com/demos/images/nature-5.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/421cd357-255c-4b8e-96f3-835fd391962e/ed_chelth.ppt"
    },
    {
        title: "Assesment Test Pilot",
        image: "https://swiperjs.com/demos/images/nature-1.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/5df1e219-9697-450b-8547-742307da00bd/uslife_inc.ppt"
    },
    {
        title: "Pwc Professional",
        image: "https://swiperjs.com/demos/images/nature-2.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/2f6d753d-fafd-4fea-991d-241b4e3da026/hlth_inceg.ppt"
    },
    {
        title: "Skill Management",
        image: "https://swiperjs.com/demos/images/nature-3.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/318f961d-af89-48a9-845a-85bc35bfc140/ed_lifexp.ppt"
    },
    {
        title: "My Profile",
        image: "https://swiperjs.com/demos/images/nature-4.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/4187fe40-f70b-4a5f-abeb-d170d87b32a6/US%20Life%20Expectancy%20Map.ppt"
    },
    {
        title: "Dashboard",
        image: "https://swiperjs.com/demos/images/nature-5.jpg",
        desc: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nisi adipisci, accusantium assumenda maiores eum fugit",
        doc: "http://www.commissiononhealth.org/PPT/421cd357-255c-4b8e-96f3-835fd391962e/ed_chelth.ppt"
    },
];